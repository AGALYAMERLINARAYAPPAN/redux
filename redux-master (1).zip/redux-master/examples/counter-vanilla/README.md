# Redux Counter Vanilla Example

This example does not require a build system or a view framework, and exists to show the raw Redux API used with ES5.

As Dan said [in the original PR for this example]():

> The new Counter Vanilla example is aimed to dispel the myth that Redux requires Webpack, React, hot reloading, sagas, action creators, constants, Babel, npm, CSS modules, decorators, fluent Latin, an Egghead subscription, a PhD, or an Exceeds Expectations O.W.L. level.
>
> Nope, it's just HTML, some artisanal `<script>` tags, and plain old DOM manipulation. Enjoy!

To try this example, just download the HTML file and open it in your browser.

(The `package.json` in this folder only exists to allow using this folder as a CodeSandbox embed, and is not required
to run the HTML file.)
